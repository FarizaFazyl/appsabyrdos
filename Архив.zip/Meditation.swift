//
//  Meditation.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 16.03.2024.
//

import SwiftUI

struct Meditation: View {
    @Environment(\.modelContext) private var modelContext
    @State private var modalType: ModalType?
    @State private var path = NavigationPath()
    var body: some View {
        NavigationStack(path: $path){
            Text("Здесь будут упражнения, чтобы справится с панической атакой")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .navigationTitle("Упражнения")
        }
        

    }
    
}

#Preview {
    Meditation()
}
