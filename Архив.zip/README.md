# MyWorkouts - Calendar Tally Video

## Extended Project Branch

![mac128](Images/mac128.png)

This branch extends what is covered in the video by adding the ability to tap on a day in the calendar to display a list of all activities that occurred on that day.

If you want to support my work, you can - </br>

<a href='https://ko-fi.com/Z8Z22WRVG' target='_blank'><img height='36' style='border:0px;height:36px;' src='Images/kofi3.png' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

