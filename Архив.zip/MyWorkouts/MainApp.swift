//
//  MainApp.swift
//  ChatSabyrDos
//
//  Created by Islam Lukmanov on 24.03.2024.
//

import SwiftUI
import Firebase

struct MainApp: View {
    @AppStorage("log_status") var logStatus: Bool = false
    var body: some View {
        if logStatus{
            MainMessagesView()
        }
        else{
            Intro()
        }
    }
}

#Preview {
    MainApp()
}
