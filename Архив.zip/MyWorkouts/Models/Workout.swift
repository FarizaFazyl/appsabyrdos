//
// Created for MyWorkouts
// by  Stewart Lynch on 2024-01-19
//
// Follow me on Mastodon: @StewartLynch@iosdev.space
// Follow me on Threads: @StewartLynch (https://www.threads.net)
// Follow me on X: https://x.com/StewartLynch
// Follow me on LinkedIn: https://linkedin.com/in/StewartLynch
// Subscribe on YouTube: https://youTube.com/@StewartLynch
// Buy me a ko-fi:  https://ko-fi.com/StewartLynch

import SwiftData
import Foundation

@Model
class Workout {
    var date: Date
    var activity: Activity?
    var comment: String
    var rating: Double
    
    init(date: Date, comment: String = "", rating: Double) {
        self.date = date
        self.rating = rating
        self.comment = comment
    }
}
