

import SwiftUI
import SwiftData

struct StartTab: View {
    @State private var tabSelection = 1
    var body: some View {
        TabView(selection: $tabSelection) {
            ActivityListView()
                .tag(1)

            CalendarHeaderView()
                .tag(2)

            MainExerciseView()
                .tag(3)

            MainMessagesView()
                .tag(4)
            

        }
        .overlay(alignment: .bottom) {
            CustomTabView(tabSelection: $tabSelection)
            .offset(y:10)}
    }
}

#Preview {
    StartTab()
        .modelContainer(Activity.preview)
}
