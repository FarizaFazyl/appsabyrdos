//
//  MessageViewSecond.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI


struct ButtonView_1: View {
    var body: some View {
        VStack {
            Text("Постарайся найти безопасное и комфортное место")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(.all)
                .offset(y:-20)
            NavigationLink(destination: MessageViewThree(), label: {
                HStack {
                    Image(systemName: "chevron.right")
                        
                        .foregroundColor(.white)
                        .padding(30)

                        
                }.background(Color(red: 0.310, green: 0.204, blue: 0.133))
                    .clipShape(Circle())
            })
        }
        .offset(x:0,y:200)
    }
}


struct MessageViewSecond: View {
    var body: some View {
        VStack {
            Image("Image_exercise_2")
                .resizable()
                .frame(width: .infinity, height: .infinity)
                .offset(x:0,y:-90)
                .overlay(ButtonView_1())
            
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 1, green: 1, blue: 1)                            .ignoresSafeArea())

        
    }
}

#Preview {
    MessageViewSecond()
}
