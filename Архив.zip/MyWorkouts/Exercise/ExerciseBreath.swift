//
//  ExerciseBreath.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI
import SwiftUI

struct ExerciseBreath: View {
    @State private var isAnimation = false
    
    var body: some View {
        VStack {
            Text("Следуй ритму дыхания")
                .font(.largeTitle)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding(.vertical, 100)
            
            ZStack {
     
                Circle()
                    .fill(Color.yellow.opacity(0.15))
                    .frame(width: 250, height: 250)
                    .scaleEffect(isAnimation ? 0.8 : 1)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true), value: isAnimation)
                
                Circle()
                    .fill(Color.yellow.opacity(0.3))
                    .frame(width: 200, height: 200)
                    .scaleEffect(isAnimation ? 0.6 : 1)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true), value: isAnimation)
                
                Circle()
                    .fill(Color.yellow)
                    .frame(width: 150, height: 150)
                    .scaleEffect(isAnimation ? 0.4 : 1)
                    .animation(Animation.easeInOut(duration: 4).repeatForever(autoreverses: true), value: isAnimation)
            }
            .onAppear {
                self.isAnimation.toggle()
            }
            Spacer()
            
        }
        .vAlign(.top)
        
        .padding()
        
    }
}






struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ExerciseBreath()
            .preferredColorScheme(.light)
    }
}
