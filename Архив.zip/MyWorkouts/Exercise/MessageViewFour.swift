//
//  MessageViewThree.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI

struct ButtonView_3: View {
    var body: some View {
        VStack {
            Text("Найди и назови 5 предметов                                                       Притронься к 4 предметам                                            Услышь и назови 3 звука    Почувствуй 2 запаха                       Определи 1 вкус")
                .font(.title2)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(.all)
            NavigationLink(destination: MessageViewFive(), label: {
                HStack {
                    Image(systemName: "chevron.right")
                        
                        .foregroundColor(.white)
                        .padding(30)

                        
                }.background(Color(red: 0.310, green: 0.204, blue: 0.133))
                    .clipShape(Circle())
            })
        }
        .offset(x:0,y:180)
    }
}
struct MessageViewFour: View {
    var body: some View {
        VStack {
            Image("Exercise_2")
                .resizable()
                .frame(width: .infinity, height: .infinity)
                .offset(x:0,y:-80)
                .overlay(ButtonView_3())
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 0.882, green: 0.882, blue: 0.878)                            )

        
    }
}

#Preview {
    MessageViewFour()
}
