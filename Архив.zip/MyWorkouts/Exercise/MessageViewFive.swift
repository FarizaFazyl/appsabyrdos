//
//  MessageViewFive.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI


struct ButtonView_4: View {
    var body: some View {
        
        VStack {
            Text("Сожми кисть в кулак, дай ей побыть в напряжении, на выдохе – расслабь ее. Проделай это с другой кистью. Получилось? Повтори это двумя руками")
                .font(.title3)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(.all)
            NavigationLink(destination: MessageViewSix(), label: {
                HStack {
                    Image(systemName: "chevron.right")
                        
                        .foregroundColor(.white)
                        .padding(30)

                        
                }.background(Color(red: 0.310, green: 0.204, blue: 0.133))
                    .clipShape(Circle())
            })
        }
        .offset(x:0,y:190)
    }
}

struct MessageViewFive: View {
    var body: some View {
        VStack {
            Image("Exercise_3")
                .resizable()
                .frame(width: .infinity, height: .infinity)
                .offset(x:0,y:-80)
                .overlay(ButtonView_4())
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 1.0, green: 0.922, blue: 0.761)                            )

        
    }
}

#Preview {
    MessageViewFive()
}
