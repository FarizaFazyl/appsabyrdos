//
//  MessageViewThree.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI

struct ButtonView_2: View {
    var body: some View {
        VStack {
            Text("Осознай и прими, что у тебя паническая атака")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(.all)
            NavigationLink(destination: MessageViewFour(), label: {
                HStack {
                    Image(systemName: "chevron.right")
                        
                        .foregroundColor(.white)
                        .padding(30)

                        
                }.background(Color(red: 0.310, green: 0.204, blue: 0.133))
                    .clipShape(Circle())
            })
        }
        .offset(x:0,y:200)
    }
}
struct MessageViewThree: View {
    var body: some View {
        VStack {
            Image("Exercise_1")
                .resizable()
                .frame(width: .infinity, height: .infinity)
                .offset(x:0,y:-50)
                .overlay(ButtonView_2())
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 1, green: 0.784, blue: 0.62)                            )

        
    }
}

#Preview {
    MessageViewThree()
}
