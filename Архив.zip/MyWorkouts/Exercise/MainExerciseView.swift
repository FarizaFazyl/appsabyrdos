//
//  MainExerciseView.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI

struct MainExerciseView: View {
    var body: some View {
        NavigationView{
            VStack {
                VStack {

                    Text("Началась паническая атака? Не переживай и попробуй эти техники!")
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .padding(.all)
                    
                }
                .offset(x:0, y:-30)
                Image("Image_exercise_3")
                    .resizable()
                    .frame(width: 300, height: 300)
                
                NavigationLink(destination: MessageViewSecond(), label: {
                    HStack {
                        Text("Начать")
                            .font(.title2)
                            .padding(15)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                    }.background(Color(red: 0.153, green: 0.169, blue: 0.541))
                        .clipShape(Capsule())
                })
                .padding()
                
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(red: 0.969, green: 0.957, blue: 0.949)                            .ignoresSafeArea())
        }
    }
}

#Preview {
    MainExerciseView()
}
