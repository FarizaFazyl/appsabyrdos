//
//  MessageViewSix.swift
//  MyWorkouts
//
//  Created by Islam Lukmanov on 29.03.2024.
//

import SwiftUI

struct ButtonView_5: View {
    var body: some View {
        
        VStack {
            Text("Если тебе хочется, попроси близких поговорить с тобой и поддержать")
                .font(.title)
                .fontWeight(.semibold)
                .multilineTextAlignment(.center)
                .padding(.all)
            NavigationLink(destination: ExerciseBreath(), label: {
                HStack {
                    Image(systemName: "chevron.right")
                        
                        .foregroundColor(.white)
                        .padding(30)

                        
                }.background(Color(red: 0.310, green: 0.204, blue: 0.133))
                    .clipShape(Circle())
            })
        }
        .offset(x:0,y:190)
    }
}


struct MessageViewSix: View {
    var body: some View {
        VStack {
            Image("Exercise_4")
                .resizable()
                .frame(width: .infinity, height: .infinity)
                .offset(x:0,y:-90)
                .overlay(ButtonView_5())
            
        }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(red: 1.0, green: 1.0, blue: 1.0)                            )

        
    }
}

#Preview {
    MessageViewSix()
}
