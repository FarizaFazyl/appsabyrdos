//
//  Intro.swift
//  ChatSabyrDos
//
//  Created by Islam Lukmanov on 25.03.2024.
//

import SwiftUI

struct Intro: View {
    var body: some View {
        NavigationView{
            VStack {
                VStack {
                    
                    Text("Добро Пожаловать в SabyrDos!")
                        .multilineTextAlignment(.center)
                        .font(.largeTitle.bold())
                    Text("Здесь вам не страшны панические атаки!")
                        .font(.callout)
                        .fontWeight(.light)
                        .padding(.bottom)
                    
                }
                .offset(x:0, y:-30)
                Image("preview_1")
                    .resizable()
                    .frame(width: 400, height: 400)
                
                NavigationLink(destination: LoginView().navigationBarBackButtonHidden(), label: {
                    HStack {
                        Text("Начать")
                            .padding(15)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                    }.background(Color(red: 0.49, green: 0.48, blue: 1.0))
                        .clipShape(Capsule())
                })
                .padding()
                
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(red: 0.969, green: 0.957, blue: 0.949)                            .ignoresSafeArea())
        }
    }
    
}

#Preview {
    Intro()
}
