
import SwiftUI
import SwiftData

struct WorkoutsListView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @State private var modalType: ModalType?
    var activity: Activity
    var body: some View {
        @Bindable var activity = activity
        Group {
            if activity.workouts.isEmpty{
                ContentUnavailableView("Создайте свою первую запись в категории \(activity.name) нажав на кнопку \(Image(systemName: "plus.circle.fill")) в правом верхнем углу", systemImage: "\(activity.icon)")
            } else {
                List(activity.workouts.sorted(
                    using: KeyPathComparator(
                        \Workout.date,
                         order: .reverse
                    )
                )
                ) { workout in
                    HStack {
                        VStack(alignment: .leading) {
                            Text(workout.date.formatted(date: .abbreviated, time: .shortened))
                            Text(workout.comment)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Text("^[\(Int(workout.rating))](inflect: true)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .swipeActions(edge: .trailing) {
                        Button(role: .destructive) {
                            if let index = activity.workouts.firstIndex(where: {$0.id == workout.id}) {
                                activity.workouts.remove(at: index)
                            }
                            
                        } label: {
                            Label("Удалить", systemImage: "trash")
                        }
                    }
                    .swipeActions(edge: .leading) {
                        Button {
                            if let index = activity.workouts.firstIndex(where: {$0.id == workout.id}) {
                                modalType = .updateWorkout(activity.workouts[index])
                            }
                        } label: {
                            Label("Редактировать", systemImage: "pencil")
                        }
                    }
                }
                .listStyle(.plain)
            }
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                    Text("\(Image(systemName: activity.icon)) \(activity.name)")
                        .font(.title)
                        .foregroundStyle(Color(hex: activity.hexColor)!)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    modalType = .newWorkout(activity)
                } label: {
                    Image(systemName: "plus.circle.fill")
                }
                .sheet(item: $modalType) { sheet in
                    sheet
                        .presentationDetents([.height(600)])
                }
            }
        }
    }
}

#Preview {
    let container = Activity.preview
    var fetchDescriptor = FetchDescriptor<Activity>()
    fetchDescriptor.sortBy = [SortDescriptor(\.name)]
    let activity = try! container.mainContext.fetch(fetchDescriptor)[0]
    return NavigationStack {
        WorkoutsListView(activity: activity)
    }
    .modelContainer(Activity.preview)
}
