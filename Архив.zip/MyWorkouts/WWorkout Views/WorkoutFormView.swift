
import SwiftUI
import SwiftData

struct WorkoutFormView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.dismiss) private var dismiss
    @State var model: WorkoutFormModel
    @State private var sliderValue1: Double = 2.5
    @State private var sliderValue2: Double = 2.5
    @State private var sliderValue3: Double = 2.5

    
    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                LabeledContent {
                    DatePicker("", selection: $model.date)
                } label: {
                    Text("Дата и время")
                }
                VStack {
                    Text("Настроение нейтральное")
                        .font(.system(size: 16, weight: .light, design: .serif))
                    Slider(
                        value: $sliderValue1,
                        in: 1...5,
                        step: 1
                    )
                    HStack {
                        Text("Плохое настроение")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:-5,y:0)
                        Text("Хорошее настроение")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:10,y:0)
                    }
                }
                VStack {
                    Text("Ни волнуюсь, ни спокоен")
                        .font(.system(size: 16, weight: .light, design: .serif))
                    Slider(
                        value: $sliderValue2,
                        in: 1...5,
                        step: 1
                    )
                    HStack {
                        Text("Волнуюсь")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:-100,y:0)
                        Text("Спокоен")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:100,y:0)
                    }
                }
                VStack {
                    Text("Средне напряжен")
                        .font(.system(size: 16, weight: .light, design: .serif))
                    Slider(
                        value: $sliderValue3,
                        in: 1...5,
                        step: 1
                    )
                    HStack {
                        Text("Напряжен")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:-85,y:0)
                        Text("Расслаблен")
                            .font(.callout)
                            .fontWeight(.black)
                            .offset(x:90,y:0)
                    }
                }
                LabeledContent {
                    
                    TextField("Как вы себя чувствуете?", text: $model.comment, axis: .vertical)
                        .textFieldStyle(.roundedBorder)
                        .frame(minHeight: 60)
                } label: {
                    Text("Заметки")
                }
                
                Button(model.updating ? "Обновить" : "Создать") {
                    if model.updating {
                        model.workout?.date = model.date
                        model.workout?.comment = model.comment
                        model.workout?.rating = round((sliderValue1 + sliderValue2 + sliderValue3)/3)
                    } else {
                        let newWorkout = Workout(date: model.date, comment: model.comment, rating: round((sliderValue1 + sliderValue2 + sliderValue3)/3))
                        model.activity?.workouts.append(newWorkout)
                    }
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.top)
                Spacer()
            }
            .padding()
            .navigationTitle(model.updating ? "Обновить" : "Создать")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

#Preview {
    let container = Activity.preview
    var fetchDescriptor = FetchDescriptor<Activity>()
    fetchDescriptor.sortBy = [SortDescriptor(\.name)]
    let activity = try! container.mainContext.fetch(fetchDescriptor)[0]
    return NavigationStack {WorkoutFormView(model: WorkoutFormModel(activity: activity))
    }
        .modelContainer(Activity.preview)
}

