
//  LoginView.swift
//  ChatSabyrDos
//
//  Created by Islam Lukmanov on 24.03.2024.
//

import SwiftUI
import Firebase
import FirebaseStorage
import FirebaseFirestore


struct OvalTextFieldStyle: TextFieldStyle {
    func _body(configuration: TextField<Self._Label>) -> some View {
        configuration
            .padding(10)
            .background()
            .cornerRadius(20)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(Color.gray, lineWidth: 0.5)
            )


    }
}



struct LoginView: View {
    @State var email: String = ""
    @State var password: String = ""
    @State var createAccount: Bool = false
    @State var showError: Bool = false
    @State var errorMessage: String = ""
    @State var isLoading: Bool = false
    @AppStorage("user_name") var userNameStored: String = ""
    @AppStorage("user_UID") var userUID: String = ""
    @AppStorage("Log_status") var logStatus: Bool = false
    var body: some View {
        NavigationView {
            VStack {
                Text("Вход в приложение")
                    .font(.largeTitle.bold())
                    .vAlign(.center)
                VStack {
                    HStack {
                        Text("Адрес эл.почты")
                        Spacer()
                    }
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                        .textFieldStyle(OvalTextFieldStyle())
                        .padding(.bottom)
                    HStack {
                        Text("Пароль")
                        Spacer()
                    }
                    SecureField("Password", text: $password)
                        .textFieldStyle(OvalTextFieldStyle())
                    
                    Button("Забыли пароль?", action: resetPassword)
                        .font(.callout)
                        .fontWeight(.medium)
                        .hAlign(.trailing)
                }
                .padding(.bottom, 200)

                NavigationLink(destination: StartTab().navigationBarBackButtonHidden(), label: {
                    HStack {
                        Text("Начать")
                            .padding(15)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                    }.background(Color(red: 0.49, green: 0.48, blue: 1.0))
                        .clipShape(Capsule())
                })
                HStack {
                    Text("Нет аккаунта?")
                        .foregroundColor(Color.gray) // Setting text color to gray
                    
                    Button(action: {
                        createAccount.toggle()
                    }) {
                        Text("Зарегистрироваться")
                            .fontWeight(.bold) // Setting text weight to bold
                            .foregroundColor(Color.blue) // Setting text color to black
                    }
                }
                
                
            }
            .padding()
            .overlay(content: {
                LoadingView(show: $isLoading)
            })
            .background(Color(red: 0.969, green: 0.957, blue: 0.949)                            .ignoresSafeArea())
            .fullScreenCover(isPresented: $createAccount) {
                RegisterView()
            }
            .alert(errorMessage, isPresented: $showError, actions:{})
        }}
    func loginUser() {
        isLoading = true
        Task {
            do{
                try await Auth.auth().signIn(withEmail: email, password: password)
                print("User Found")
                try await fetchUser()
            }
            catch{
                await setError(error)
            }
        }
    }
    func resetPassword() {
        Task {
            do{
                try await Auth.auth().sendPasswordReset(withEmail: email)
                print("Link Sent")
            }
            catch{
                await setError(error)
            }
        }
    }
    func fetchUser()async throws{
        guard let userID = Auth.auth().currentUser?.uid else{return}
        let user = try await Firestore.firestore().collection("Users").document(userID).getDocument(as: User.self)
        //MARK: UI Updating Must Be Run On Main Thread
        await MainActor.run(body: {
            // Setting UserDefaults data and Changing App's Auth Status
            userUID = userID
            userNameStored = user.username
            logStatus = false
        })
    }
    func setError(_ error: Error)async{
        //MARK: UI Must be Updated on Main Thread
        await MainActor.run(body: {
            errorMessage = error.localizedDescription
            showError.toggle()
            isLoading = false
        })
    }
}

#Preview {
    LoginView()
}

struct RegisterView: View {
    // MARK: User Details
    @State var email: String = ""
    @State var password: String = ""
    @State var UserName: String = ""
    @Environment (\.dismiss) var dismiss
    @State var showError: Bool = false
    @State var errorMessage: String = ""
    @AppStorage("log_status") var logStatus: Bool = false
    @AppStorage("user_name") var userNameStored: String = ""
    @AppStorage("user_UID") var userUID: String = ""
    @State var isLoading: Bool = false
    var body: some View {
        NavigationView{
            VStack(spacing: 10) {
                Text("Регистрация")
                    .font(.largeTitle.bold())
                    .vAlign(.center)
                VStack {
                    HStack {
                        Text("Имя пользователя")
                        Spacer()
                    }
                    TextField("User name", text: $UserName)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .textFieldStyle(OvalTextFieldStyle())
                        .padding(.bottom)
                    HStack {
                        Text("Адрес эл.почты")
                        Spacer()
                    }
                    TextField("Email", text: $email)
                        .keyboardType(.emailAddress)
                        .autocapitalization(.none)
                        .textFieldStyle(OvalTextFieldStyle())
                        .padding(.bottom)
                    HStack {
                        Text("Пароль")
                        Spacer()
                    }
                    SecureField("Password", text: $password)
                        .textFieldStyle(OvalTextFieldStyle())
                    
                    
                }

                
                NavigationLink(destination: StartTab().navigationBarBackButtonHidden(), label: {
                    HStack {
                        Text("Начать")
                            .padding(15)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                    }.background(Color(red: 0.49, green: 0.48, blue: 1.0))
                        .clipShape(Capsule())
                })
                .vAlign(.center)
                
                HStack {
                    Text("Уже есть аккаунт?")
                        .foregroundColor(Color.gray)
                    
                    Button(action: {
                        dismiss()
                    }) {
                        Text("Войти")
                            .fontWeight(.bold)
                            .foregroundColor(Color.blue)
                    }
                }
                .offset(x:0, y: -35)
            }
            .padding()
            .background(Color(red: 0.969, green: 0.957, blue: 0.949))
            .ignoresSafeArea()
            .overlay(content: {
                LoadingView(show: $isLoading)
            })
            .alert(errorMessage, isPresented: $showError, actions:{})
            
        }}
    func registerUser(){
        isLoading = true
        Task{
            do{
                try await Auth.auth().createUser(withEmail: email, password: password)
                guard let userUID = Auth.auth().currentUser?.uid else {
                        return // Return if user UID is nil
                    }
                let user = User(username: UserName, userUID: userUID, userEmail: email)
                let _ = try Firestore.firestore().collection("Users").document(userUID).setData(from: user, completion: {
                    error in if error == nil {
                        print("Saved Successfully")
                        userNameStored = UserName
                        self.userUID = userUID
                        logStatus = true
                    }
                })
                logStatus = false
            }
            catch{
                try await Auth.auth().currentUser?.delete()
                await setError(error)
            }
        }
        
    }
    func setError(_ error: Error) async {
        // Ensure UI updates are performed on the main thread
        await MainActor.run(body:{
            errorMessage = error.localizedDescription
            
            // Toggle the flag to show the error alert
            showError.toggle()
            isLoading = false
        })
    }



}
