//
//  User.swift
//  ChatSabyrDos
//
//  Created by Islam Lukmanov on 25.03.2024.
//

import SwiftUI
import FirebaseFirestoreSwift

struct User: Identifiable,Codable {
    @DocumentID var id: String?
    var username: String
    var userUID: String
    var userEmail: String

    enum CodingKeys: String, CodingKey {
        case id
        case username
        case userUID
        case userEmail
    }
}

